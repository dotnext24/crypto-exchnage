import { SchoolTemplatePage } from './app.po';

describe('School App', function() {
  let page: SchoolTemplatePage;

  beforeEach(() => {
    page = new SchoolTemplatePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
