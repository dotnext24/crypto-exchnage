﻿using Abp.Application.Services;
using School.MultiTenancy.Dto;

namespace School.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedTenantResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}

